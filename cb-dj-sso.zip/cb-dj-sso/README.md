# Django SSO using Google, Facebook and GitHub.

This is a part of YouTube Tutorial video on How to implement Single Sign-On (SSO) in your Django Application.

English : https://youtu.be/GQySb3W2feo

Malayalam : https://youtu.be/2HauttTuTdA

## Usage

![OAuth2 Flow Diagram](https://github.com/akjasim/cb-dj-sso/blob/main/oauth2-flow.png?raw=true)
